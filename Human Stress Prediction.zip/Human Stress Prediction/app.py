#Main Web App for Analysis and Prediction of Human Stress from SubReddit Mental Health Data

#Libraries 

from flask import Flask, render_template, request
app = Flask(__name__)

# Array
import numpy as np

# Dataframe
import pandas as pd

# Excel 

from openpyxl import Workbook
import openpyxl

#Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# warnings
import warnings
warnings.filterwarnings('ignore')

# Regular Expression
import re 

# Handling string
import string

# NLP tool
import spacy

nlp=spacy.load('en_core_web_sm')
from spacy.lang.en.stop_words import STOP_WORDS

# Importing Natural Language Tool Kit for NLP operations
import nltk
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('punkt')
nltk.download('omw-1.4')                                #Multilingual Wordnet Data from OMW with newer Wordnet versions
from nltk.stem import WordNetLemmatizer

from wordcloud import WordCloud, STOPWORDS
from nltk.corpus import stopwords
from collections import Counter

# Vectorization
from sklearn.feature_extraction.text import TfidfVectorizer

# Model Building
from sklearn.model_selection import GridSearchCV,StratifiedKFold,KFold,train_test_split,cross_val_score,cross_val_predict
from sklearn.linear_model import LogisticRegression,SGDClassifier
from sklearn import preprocessing
from sklearn.naive_bayes import MultinomialNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import StackingClassifier,RandomForestClassifier,AdaBoostClassifier
from sklearn.neighbors import KNeighborsClassifier

#Model Evaluation
from sklearn.metrics import confusion_matrix,classification_report,accuracy_score,f1_score,precision_score
from sklearn.pipeline import Pipeline

# Time
from time import time

import statistics as st

#Data Reading
stress_c= pd.read_csv('C:/Users/Asus/Desktop/human_stress_prediction/Stress.csv')

# Copy
stress=stress_c.copy()


#Pie Chart

# lst=['subreddit','label']
# plt.figure(figsize=(15,12))
# for i in range(len(lst)):
#     plt.subplot(1,2,i+1)
#     a=stress[lst[i]].value_counts()
#     lbl=a.index
#     plt.title(lst[i]+'_Distribution')
#     plt.pie(x=a,labels=lbl,autopct="%.1f %%")
#     plt.savefig('static/graphs/pie.png')


#Bar Graph

# plt.figure(figsize=(20,12))
# plt.title('Subreddit wise stress count')
# plt.xlabel('Subreddit')
# sns.countplot(data=stress,x='subreddit',hue='label',palette='gist_heat')
# plt.savefig('static/graphs/bargraph.png')



#Machine Learning

#defining function for preprocessing
def preprocess(text,remove_digits=True):
    text = re.sub('\W+',' ', text)                                        #for replacing non-word characters
    text = re.sub('\s+',' ', text)                                        #for replacng extra spaces
    text = re.sub("(?<!\w)\d+", "", text)                                 # Remove all numbers except those attached to a word
    text = re.sub("-(?!\w)|(?<!\w)-", "", text)                           # Remove all hyphens except between two words
    text=text.lower()
    nopunc=[char for char in text if char not in string.punctuation]      #for removing punctuation in the strings
    nopunc=''.join(nopunc)
    nopunc=' '.join([word for word in nopunc.split() if word.lower() not in stopwords.words('english')])   #for removing stop words
    
    
    return nopunc
# Defining a function for lemitization
def lemmatize(words):
   
    words=nlp(words)
    lemmas = []
    for word in words:
        
        lemmas.append(word.lemma_)
    return lemmas

#converting them into string
def listtostring(s):
    str1=' '
    return (str1.join(s))

def clean_text(input):
    word=preprocess(input)
    lemmas=lemmatize(word)
    return listtostring(lemmas)

stress['clean_text']=stress['text'].apply(clean_text)

# Defining target & feature for ML model building
x=stress['clean_text']
y=stress['label']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=1)

x1=stress['clean_text']
y1=stress['subreddit']
x1_train,x1_test,y1_train,y1_test=train_test_split(x1,y1,test_size=0.3,random_state=1)


# Self defining function to convert the data into vector form by tf idf vectorizer and classify and create model by Logistic regression

def model_lr_tf(x_train, x_test, y_train, y_test):
    
    global acc_lr_tf,f1_lr_tf
    
    # Text to vector transformation 
    vector = TfidfVectorizer()
    x_train = vector.fit_transform(x_train)
    x_test = vector.transform(x_test)
 
    ovr = LogisticRegression()

    #fitting training data into the model & predicting
    t0 = time()

    ovr.fit(x_train, y_train)
    
    y_pred = ovr.predict(x_test)
    
    # Model Evaluation for Labels
    
    conf=confusion_matrix(y_test,y_pred)
    acc_lr_tf=accuracy_score(y_test,y_pred)
    f1_lr_tf=f1_score(y_test,y_pred,average='weighted')
    print('Time :',time()-t0)
    print('Accuracy: ',acc_lr_tf)
    print(10*'===========')
    print('Confusion Matrix: \n',conf)
    print(10*'===========')
    print('Classification Report: \n',classification_report(y_test,y_pred))
    

    
    return y_test,y_pred,acc_lr_tf

def model1_lr_tf(x_train, x_test, y_train, y_test):
    
    global acc1_lr_tf,f11_lr_tf
    
    # Text to vector transformation 
    vector = TfidfVectorizer()
    x_train = vector.fit_transform(x_train)
    x_test = vector.transform(x_test)

    ovr = LogisticRegression()

    #fitting training data into the model & predicting
    t0 = time()

    ovr.fit(x_train,y_train)
    
    y_pred = ovr.predict(x_test)
    
    
    #Model Evaluation for Categories of Stress

    conf=confusion_matrix(y_test,y_pred)
    acc_lr_tf=accuracy_score(y_test,y_pred)
    f1_lr_tf=f1_score(y_test,y_pred,average='weighted')
    print('Time :',time()-t0)
    print('Accuracy: ',acc_lr_tf)
    print(10*'===========')
    print('Confusion Matrix: \n',conf)
    print(10*'===========')
    print('Classification Report: \n',classification_report(y_test,y_pred))

    
    return y_test,y_pred,acc_lr_tf




# Evaluating Models

print('********************Logistic Regression*********************')
print('\n')
model_lr_tf(x_train, x_test, y_train, y_test)
print('\n')
print(30*'==========')
print('\n')

# Evaluating Models

print('********************Logistic Regression*********************')
print('\n')
model1_lr_tf(x1_train, x1_test, y1_train,y1_test)
print('\n')
print(30*'==========')
print('\n')


# Using cross validation method to avoid overfitting
vector = TfidfVectorizer()

x_train_v = vector.fit_transform(x_train)
x_test_v  = vector.transform(x_test)
###############################################################################
# Model building
lr =LogisticRegression()

m  =[lr]
results, mean_results, p, f1_test=list(),list(),list(),list()

################################################################################
#Model fitting,cross-validating and evaluating performance

def algor(model):
    print('\n',i) 
    pipe=Pipeline([('model',model)])
    pipe.fit(x_train_v,y_train)
    cv=StratifiedKFold(n_splits=5)
    n_scores=cross_val_score(pipe,x_train_v,y_train,scoring='f1_weighted',cv=cv,n_jobs=-1,error_score='raise') # As it is an Imbalance data so f1 score will give a better accuracy than normal accuracy.
    results.append(n_scores)
    mean_results.append(st.mean(n_scores))
    print('f1-Score(train): mean= (%.3f), min=(%.3f)) ,max= (%.3f), stdev= (%.3f)'%(st.mean(n_scores), min(n_scores), max(n_scores),np.std(n_scores)))
    y_pred=cross_val_predict(model,x_train_v,y_train,cv=cv)
    p.append(y_pred)
    f1=f1_score(y_train,y_pred, average = 'weighted')
    f1_test.append(f1)
    print('f1-Score(test): %.4f'%(f1))

for i in m:
    algor(i)



x=stress['clean_text']
y=stress['label']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=1)

vector = TfidfVectorizer()
x_train = vector.fit_transform(x_train)
x_test = vector.transform(x_test)
model_lr_tf=LogisticRegression()

model_lr_tf.fit(x_train,y_train)
y_pred=model_lr_tf.predict(x_test)
# Model Evaluation
    
conf=confusion_matrix(y_test,y_pred)
acc_lr=accuracy_score(y_test,y_pred)
f1_lr=f1_score(y_test,y_pred,average='weighted')

print('Accuracy: ',acc_lr)
print('F1 Score: ',f1_lr)
print(10*'===========')
print('Confusion Matrix: \n',conf)
print(10*'===========')
print('Classification Report: \n',classification_report(y_test,y_pred))

x=stress['clean_text']
y=stress['subreddit']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=1)

vector = TfidfVectorizer()
x_train = vector.fit_transform(x_train)
x_test = vector.transform(x_test)
model1_lr_tf=LogisticRegression()

model1_lr_tf.fit(x_train,y_train)
y_pred=model1_lr_tf.predict(x_test)
# Model Evaluation
    
conf=confusion_matrix(y_test,y_pred)
acc_lr=accuracy_score(y_test,y_pred)
f1_lr=f1_score(y_test,y_pred,average='weighted')

print('Accuracy: ',acc_lr)
print('F1 Score: ',f1_lr)
print(10*'===========')
print('Confusion Matrix: \n',conf)
print(10*'===========')
print('Classification Report: \n',classification_report(y_test,y_pred))

#----------------------------------------------------------------------------------------------------------------#

# # Defining target & feature for ML model building
# x1=stress['clean_text']
# y1=stress['subreddit']
# x1_train,x1_test,y1_train,y1_test=train_test_split(x1,y1,test_size=0.3,random_state=1)

# Self defining function to convert the data into vector form by tf idf vectorizer and classify and create model by Logistic regression

# def model1_lr_tf(x1_train, x1_test, y1_train, y1_test):
#     global acc1_lr_tf,f11_lr_tf
#     # Text to vector transformation 
#     vector1 = TfidfVectorizer()
#     x_train1 = vector.fit_transform(x1_train)
#     x_test1 = vector.transform(x1_test)
    

    
 
#     ovr1 = LogisticRegression()
    
#     #fitting training data into the model & predicting
#     t0 = time()

#     ovr.fit(x_train, y_train)
    
#     y_pred = ovr.predict(x_test)
    
#     # Model Evaluation
    
#     conf=confusion_matrix(y_test,y_pred)
#     acc_lr_tf=accuracy_score(y_test,y_pred)
#     f1_lr_tf=f1_score(y_test,y_pred,average='weighted')
#     print('Time :',time()-t0)
#     print('Accuracy: ',acc_lr_tf)
#     print(10*'===========')
#     print('Confusion Matrix: \n',conf)
#     print(10*'===========')
#     print('Classification Report: \n',classification_report(y_test,y_pred))
    
    
#     return y_test,y_pred,acc_lr_tf





#----------------------------------------------------------------------------------------------------------------#

#Web app routing

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analysis')
def analysis():
    return render_template('analysis_1.html')

@app.route('/analysis2')
def analysis2():
    return render_template('analysis_2.html')

@app.route('/analysis3')
def analysis3():
    return render_template('analysis_3.html')

@app.route('/analysis4')
def analysis4():
    return render_template('analysis_4.html')

@app.route('/algorithm_1')
def algorithm_1():
    return render_template('algorithm_1.html')

@app.route('/algorithm_2')
def algorithm_2():
    return render_template('algorithm_2.html')

@app.route('/wordcloud_1')
def wordcloud_1():
    return render_template('wordcloud_1.html')

@app.route('/wordcloud_0')
def wordcloud_0():
    return render_template('wordcloud_0.html')

wb = Workbook()
ws = wb.active


@app.route('/prediction',methods=["GET","POST"])
def prediction():

    # wb = Workbook()
    # ws = wb.active

    label = "Hello"
    label1 = ""
    if request.method == "POST":
        data = request.form["text"] 
        data = [data]
        data = vector.transform(data)
        
        stress_category = model_lr_tf.predict(data)
        stress_category = stress_category[0]

        if(model_lr_tf.predict(data)==[1]):
            label = "The person is stressed!"
            label1 = model1_lr_tf.predict(data)
            label1 = ' '.join(label1)
            label1 = label1.upper()
        elif(model_lr_tf.predict(data)==[0]):
            label = "The person is relaxed!"
            label1 = model1_lr_tf.predict(data)
            label1 = ' '.join(label1)
            label1 = label1.upper()

        excel_data = [label1,stress_category]

        ws.append(excel_data)
        wb.save("C:/Users/Asus/Desktop/human_stress_prediction/stress_outcomes.xlsx")

        # label1 = model1_lr_tf.predict(data)
        
       

    return render_template('prediction.html',variable = label,variable1 = label1)

@app.route('/algorithms')
def algorithms():
    return render_template('4.html')

@app.route('/matrix')
def matrix():
    return render_template('5.html')


#Program run

if __name__ == "__main__":
    app.run(debug=True)